#include <stdlib.h>

void *myrealloc(void *p, size_t nz);

double **geraNULL(int n, int m);