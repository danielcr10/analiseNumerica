struct matrix *Jacobi(int n, int m, struct matrix *M);

struct matrix *SSOR(int n,int m, struct matrix *M, double w);